Description: this program allows you to scan through our database in order to find books by a certain genre. In order to do that you must including tags into the search adress (ex. tech or history). You can also include sorting parameters (type and direction). Please follow the example bellow: http://localhost:8080/api/posts?tags=history,tech&sortBy=likes&direction=desc


To start the application type into command line: 
    $ npm install
Then type
    $ node app.js

